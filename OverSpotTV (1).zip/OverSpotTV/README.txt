OverSpot TV
===========
1. Unzip the folder and open index.html in a browser (Chrome works best).
   For a TV: host the folder on any web server, or put it in a WebView / TV browser.
2. Shows live in shows.js. The eight included shows are free open movies from the
   Blender Foundation (Creative Commons). They stream from the internet.
   Four play with the built-in player; four (Spring, Cosmos Laundromat, Agent 327,
   Caminandes) open through an embedded YouTube/PeerTube player.
3. Add your own: copy a block in shows.js, set title, tags and src
   (a web link or a file in the "shows" folder).
Controls: arrow keys move, Enter/OK selects, Esc/Back goes back.
