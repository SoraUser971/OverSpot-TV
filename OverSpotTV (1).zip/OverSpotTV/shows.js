// OverSpot TV - show catalog.
// Add a show by copying one block below. Three ways to give it a source:
//   src:   "https://.../movie.mp4"  or a file in the "shows" folder, e.g. "shows/my-movie.mp4"
//   embed: "https://www.youtube-nocookie.com/embed/VIDEO_ID?autoplay=1&rel=0&playsinline=1"
//          (YouTube or PeerTube embed link, for shows that have no direct video file)
// tags decide which pages a show appears on: kids, movie, show, best, live.
// Optional: poster: "shows/my-movie.jpg"  and  credit: "text shown in the player".
var YT = function (id) { return "https://www.youtube-nocookie.com/embed/" + id + "?autoplay=1&rel=0&playsinline=1"; };
var BUCKET = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/";
window.SHOWS = [
  { title: "Big Buck Bunny", tags: ["kids", "show", "best"], src: BUCKET + "BigBuckBunny.mp4", credit: "\u00a9 Blender Foundation | CC BY 3.0" },
  { title: "Sintel", tags: ["movie", "best"], src: BUCKET + "Sintel.mp4", credit: "\u00a9 Blender Foundation | CC BY 3.0" },
  { title: "Tears of Steel", tags: ["movie", "best"], src: BUCKET + "TearsOfSteel.mp4", credit: "\u00a9 Blender Foundation | CC BY 3.0" },
  { title: "Elephants Dream", tags: ["show"], src: BUCKET + "ElephantsDream.mp4", credit: "\u00a9 Blender Foundation | CC BY 2.5" },
  { title: "Spring", tags: ["kids", "movie", "best"], embed: "https://video.blender.org/videos/embed/x3QKwgFXGZQ7yvCTD2wHJA", credit: "\u00a9 Blender Foundation | Creative Commons" },
  { title: "Cosmos Laundromat", tags: ["movie", "best"], embed: YT("Y-rmzh0PI3c"), credit: "\u00a9 Blender Foundation | Creative Commons" },
  { title: "Agent 327: Operation Barbershop", tags: ["show"], embed: YT("mN0zPOpADL4"), credit: "\u00a9 Blender Foundation | Creative Commons" },
  { title: "Caminandes: Llamigos", tags: ["kids", "show"], embed: YT("SkVqJ1SGeL0"), credit: "\u00a9 Blender Foundation | Creative Commons" }
];
